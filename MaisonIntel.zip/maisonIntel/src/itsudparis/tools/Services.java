package itsudparis.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.xerces.impl.dv.util.Base64;

import com.hp.hpl.jena.rdf.model.Model;

public class Services {

	private String NS = "";
	private Model model = JenaEngine.readModel("data/maison_inteligente(2).owl");

	
	public void addHorloge(String periode, int heure, String jour, int temperature) {
		if(model != null) {
	
			NS = model.getNsPrefixURI("");
			
			JenaEngine.updateValueOfDataTypeProperty(model, NS, "clock", "heureSemaine", heure);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, "clock", "joursSemaine", jour);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, "clock", "Periode", periode);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, "thermometre", "tempEmbiante", temperature);
			
			System.out.println("Horloge Enregistrer!");
		}else {
			System.out.println("Error when reading model from ontology");
		}
	}
	
	public void getChambres() {
		
		String[] s = JenaEngine.executeQueryFile(model, "data/queryChambre.txt").split("ns:");
		for(int i = 1; i < s.length; i++ ){
			String[] t = s[i].split(" | ");
			for(String j : t) {
				if(j.indexOf("Chambre") != -1) {
					System.out.println(j + "\n");
				}
			}
		}
	}
	
	public void addPersonne(String nom, int age, int heureDormir, int heureReveil, int prefTemperature, String chambre, int heureLavage, String jourLavage) {
		
		if(model != null) {
			
			//lire le Namespace de l’ontologie
			NS = model.getNsPrefixURI("");
			
			JenaEngine.createInstanceOfClass(model, NS, "Personnes", nom);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, nom, "age", age);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, nom, "nom", nom);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, nom, "PrefHeurD", heureDormir);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, nom, "PrefHeurRev", heureReveil);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, nom, "PrefTemp", prefTemperature);
			JenaEngine.updateValueOfObjectProperty(model, NS, nom, "EstDans", chambre);
			JenaEngine.updateValueOfDataTypeProperty(model, NS, nom, "HeureLavage", heureLavage);
			JenaEngine.updateValueOfObjectProperty(model, NS, nom, "joursLavage", jourLavage);
			
			System.out.println("\n" + nom + " created!");
		}else {
			System.out.println("Error when reading model from ontology");
		}
	}
	
	
	public String getClimatiseur() {
		String chaine = "";
		int p = 0;
		
		Model inferedModel = JenaEngine.readInferencedModelFromRuleFile(model, /*"data/rules.txt"*/"data/owlrules.txt");
		
		String[] s = JenaEngine.executeQueryFile(inferedModel, "data/queryClim.txt").split("\"");
		for(int i = 1; i < s.length; i++ ){
			String[] t = s[i].split(" | ");
			
			if(p == 0) {
				chaine = t[0] + ";";
				p++;
			}else if(p == 1 && s.length == 5) {
				chaine += t[3];
				p++;
			}else if(p == 1 && s.length > 5) {
				chaine += t[2];
				p++;
			}
		}
		return chaine;
	}
	
	public String getMachineL() {
		String chaine = "";

		Model inferedModel = JenaEngine.readInferencedModelFromRuleFile(model, "data/owlrules.txt");
		String[] s = JenaEngine.executeQueryFile(inferedModel, "data/queryMachineL.txt").split("\"");
		int j =0;
		for(int i = 1; i < s.length; i++ ){
			if(s[i].indexOf("e") != -1 && j == 0) {
				chaine = s[i];
				j++;
			}
		}
		return chaine;
	}

	public String getLuminosite() {
		String chaine = "";
		int p = 0;
		int y = 0;
		Model inferedModel = JenaEngine.readInferencedModelFromRuleFile(model, "data/owlrules.txt");
		String[] s = JenaEngine.executeQueryFile(inferedModel, "data/queryLampe.txt").split("=");
		for(int i = 1; i < s.length; i++ ){
			String[] t = s[i].split(" | ");
			for(String k : t) {
				if(k.length() != 0) {
					String[] e = k.split("\"");
					for(String z : e) {
						if(p == 1) {
							chaine = z + ";";
							p++;
						}else if(z.indexOf("e") != -1 && y == 0) {
							chaine += z;
							y++;
						}
						p++;
					}
				}
			}
		}
		return chaine;
	}
}
