package itsudparis.application;

import java.util.Scanner;

import itsudparis.tools.Services;

public class Main {

	public static void main(String[] args) {

		Scanner sc;
		Services rest = new Services();

		System.out.println("\n ************************** HELLO ************************** \n\n");
		System.out.println("\n ******* Saisisez les informations du jour  ******* \n\n");
		//Modifier l'horloge
		System.out.println("L'Heure ? \n");
		sc = new Scanner(System.in);
		int heure = Integer.parseInt(sc.nextLine());

		System.out.println("Le Jour ? \n");
		sc = new Scanner(System.in);
		String jour =  sc.nextLine();

		System.out.println("Saison ? \n");
		sc = new Scanner(System.in);
		String periode =  sc.nextLine();

		//Modifier la temperature
		System.out.println("Temperature ? \n");
		sc = new Scanner(System.in);
		int temperature = Integer.parseInt(sc.nextLine());

		rest.addHorloge(periode, heure, jour, temperature);

		// Ajouter une nouvelle personne
		System.out.println("\n\n******** Informaions Personnel et preference ********\n\n");
		System.out.println("Nom ?");
		sc = new Scanner(System.in);
		String nom =  sc.nextLine();

		System.out.println("Age ?");
		sc = new Scanner(System.in);
		int age = Integer.parseInt(sc.nextLine());

		System.out.println("Preference heure de dormir ?");
		sc = new Scanner(System.in);
		int heureDormir = Integer.parseInt(sc.nextLine());

		System.out.println("Preference heure de reveil ?");
		sc = new Scanner(System.in);
		int heureReveil = Integer.parseInt(sc.nextLine());

		System.out.println("Preference temperature ?");
		sc = new Scanner(System.in);
		int prefTemperature = Integer.parseInt(sc.nextLine());

		System.out.println("Heure pref machine à laver ?");
		sc = new Scanner(System.in);
		int heureLavage = Integer.parseInt(sc.nextLine());

		System.out.println("Jour pref machine à laver ?");
		sc = new Scanner(System.in);
		String jourLavage = sc.nextLine();

		System.out.println("\nLes chambres qui sont occupées:");
		rest.getChambres();
		
		System.out.println("\n      Chambre ?");
		sc = new Scanner(System.in);
		String chambre = sc.nextLine();

		rest.addPersonne(nom, age, heureDormir, heureReveil, prefTemperature, chambre, heureLavage, jourLavage);

		String[] lamp = rest.getLuminosite().split(";");
		
		if(lamp[1].equals("eteint")) {
				System.out.println("\n ************************ Lampe éteinte! ************************\n");
		}else {
			System.out.println("\n ************************ Lampe allumée! ************************\n");
		}

		String[] clim = rest.getClimatiseur().split(";");
		System.out.println("getClimatiseur  :   "+clim[0]);
		if(clim[0].equals("eteint")) {
			
			System.out.println("\n ************************ Climatisuer éteint! ************************\n");
		}else {
			
			System.out.println("\n************************ Climatiseur allumé! ************************\n");
		}

		System.out.println("getMachineL    "+ rest.getMachineL());
		if(rest.getMachineL().equals("eteint")){
			
			System.out.println("\n************************ Machine à laver éteinte! ************************\n");
		}else {
			
			System.out.println("\n************************ Machine à laver allumée! ************************\n");
		}
	}
}